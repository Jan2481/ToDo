# API Node.js 

nainstalovat NodeJs

npm install  - instalace balíčků
npm run dev  - spuštění backendu na portu 3000

