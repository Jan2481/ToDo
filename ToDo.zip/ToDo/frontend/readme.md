
# FRONTEND ToDo

Spustenie vo Web Serveru
   -npm install
   -npm run webserver - spusti web server na porte 8080
   

