//METRO ENGINE 
let pageLoader;
Metro.storage.setItem('DetectedLanguage', (navigator.language || navigator.userLanguage).substring(0, 2));
if (Metro.storage.getItem('UserAutomaticTranslate', null) == null) { Metro.storage.setItem('UserAutomaticTranslate', false); }
if (Metro.storage.getItem('WebScheme', null) == null) {
	Metro.storage.setItem('WebScheme', "sky-net.css");
	ChangeSchemeTo(Metro.storage.getItem('WebScheme', null));
}


function hidePageLoading() { Metro.activity.close(pageLoader); }
function showPageLoading() {
	if (pageLoader != undefined) {
		if (pageLoader[0]["DATASET:UID:M4Q"] == undefined) { pageLoader = null; }
		else {
			try { Metro.activity.close(pageLoader); } catch {
				try { pageLoader.close(); } catch { pageLoader = pageLoader[0]["DATASET:UID:M4Q"].dialog; pageLoader.close(); }; pageLoader = null;
			}
		}
	}
	pageLoader = Metro.activity.open({ type: 'atom', style: 'dark', overlayClickClose: true, });
}



